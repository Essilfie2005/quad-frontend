import { Ionicons } from "@expo/vector-icons";
import { createDrawerNavigator, DrawerActions } from "@react-navigation/drawer";
import { useNavigation } from "@react-navigation/native";
import { withLayoutContext } from "expo-router";
import React from "react";
import { TouchableOpacity } from "react-native";

const Drawer = createDrawerNavigator();
const DrawerNavigator = withLayoutContext(Drawer.Navigator);

// 🔥 Custom hamburger button component
function HamburgerMenu() {
  const navigation = useNavigation();

  return (
    <TouchableOpacity
      style={{ marginLeft: 15 }}
      onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
    >
      <Ionicons name="menu" size={24} color="black" />
    </TouchableOpacity>
  );
}

export default function DrawerLayout() {
  return (
    <DrawerNavigator
      screenOptions={{
        headerLeft: () => <HamburgerMenu />, // ← ✅ Set hamburger for all screens
      }}
    >
      <Drawer.Screen name="bookmarks" options={{ title: "Bookmarks" }} />
      <Drawer.Screen name="settings" options={{ title: "Settings" }} />
      <Drawer.Screen name="support" options={{ title: "Support" }} />
    </DrawerNavigator>
  );
}