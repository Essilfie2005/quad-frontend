import React from "react";
import {
    Alert,
    Linking,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from "react-native";

export default function SupportScreen() {
  const openMail = () => {
  const email = "support@quadapp.com";
  Linking.openURL(`mailto:${email}?subject=QUAD Support&body=Hi, I need help with...`);
};
    

  const handleFeedback = () => {
    Alert.prompt("Send Feedback", "Tell us what you think about QUAD", [
      { text: "Cancel", style: "cancel" },
      { text: "Send", onPress: (text) => console.log("Feedback:", text) },
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Support</Text>

      {/* FAQ */}
      <Text style={styles.subHeader}>FAQs</Text>
      <View style={styles.card}>
        <Text style={styles.question}>• How do I change my password?</Text>
        <Text style={styles.answer}>
          Go to Settings &gt; Account &gt; Change Password.
        </Text>
        <Text style={styles.question}>• How do I delete my account?</Text>
        <Text style={styles.answer}>
          Contact support at the email below for account deletion.
        </Text>
      </View>

      {/* Contact Support */}
      <Text style={styles.subHeader}>Need More Help?</Text>
      <TouchableOpacity style={styles.button} onPress={openMail}>
        <Text style={styles.buttonText}>Contact Support</Text>
      </TouchableOpacity>

      {/* Feedback */}
      <Text style={styles.subHeader}>Feedback</Text>
      <TouchableOpacity style={styles.outlineButton} onPress={handleFeedback}>
        <Text style={styles.outlineText}>Send Feedback</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F6F9FC",
    padding: 20,
  },
  header: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#1E1E1E",
  },
  subHeader: {
    fontSize: 16,
    fontWeight: "600",
    marginTop: 20,
    marginBottom: 10,
    color: "#444",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 16,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  question: {
    fontWeight: "600",
    marginTop: 10,
    color: "#333",
  },
  answer: {
    fontSize: 14,
    marginBottom: 10,
    color: "#666",
  },
  button: {
    backgroundColor: "#1DA1F2",
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 10,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "600",
    textAlign: "center",
    fontSize: 16,
  },
  outlineButton: {
    borderColor: "#1DA1F2",
    borderWidth: 1.5,
    paddingVertical: 12,
    borderRadius: 10,
    marginTop: 10,
  },
  outlineText: {
    textAlign: "center",
    color: "#1DA1F2",
    fontWeight: "600",
    fontSize: 16,
  },
});