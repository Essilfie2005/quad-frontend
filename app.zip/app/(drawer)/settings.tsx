import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
    Alert,
    ScrollView,
    StyleSheet,
    Switch,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';

export default function SettingsScreen() {
  const router = useRouter();
  const [isDarkMode, setIsDarkMode] = useState(false);

  const handleToggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    // You can hook this into your theme context/provider later
  };

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log Out', style: 'destructive', onPress: () => router.replace('/login') },
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Settings</Text>

      {/* Account Section */}
      <Text style={styles.sectionHeader}>Account</Text>
      <TouchableOpacity style={styles.item} onPress={() => router.push('/drawer/change-email')}>
        <Text style={styles.itemText}>Change Email</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.item} onPress={() => router.push('/drawer/change-password')}>
        <Text style={styles.itemText}>Change Password</Text>
      </TouchableOpacity>

      {/* Preferences Section */}
      <Text style={styles.sectionHeader}>Preferences</Text>
      <View style={styles.item}>
        <Text style={styles.itemText}>Dark Mode</Text>
        <Switch value={isDarkMode} onValueChange={handleToggleDarkMode} />
      </View>

      {/* Support Section */}
      <Text style={styles.sectionHeader}>Support</Text>
      <TouchableOpacity style={styles.item} onPress={() => router.push('/drawer/help')}>
        <Text style={styles.itemText}>Help Center</Text>
      </TouchableOpacity>

      {/* About Section */}
      <Text style={styles.sectionHeader}>About QUAD</Text>
      <TouchableOpacity style={styles.item} onPress={() => router.push('/drawer/about')}>
        <Text style={styles.itemText}>App Info</Text>
      </TouchableOpacity>
      <Text style={styles.version}>Version 1.0.0</Text>

      {/* Logout */}
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F6F9FC',
    padding: 20,
  },
  header: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 25,
    color: '#1E1E1E',
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 20,
    marginBottom: 10,
    color: '#444',
  },
  item: {
    paddingVertical: 14,
    borderBottomColor: '#E0E0E0',
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  itemText: {
    fontSize: 16,
    color: '#333',
  },
  version: {
    marginTop: 5,
    color: '#888',
    fontSize: 12,
  },
  logoutButton: {
    marginTop: 40,
    backgroundColor: '#FF3B30',
    paddingVertical: 14,
    borderRadius: 10,
  },
  logoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
});